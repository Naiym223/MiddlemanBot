module.exports = {
    token: "MTIzNDIwOTI2ODA3NzQzMjk4Mw.Geyypr.VSolAcE6_SCxHQT4x6ol1x4xFqcQcPu66n9w7s",
    prefix: '$',
    footer: `Made by DxubleG ${new Date()}`,
    colors: {
        info: '#5b57d9',
        error: '#de554e',
        neutral: '#f2f255',
        success: '#43d177'
    },
    mongoURL: "mongodb+srv://notsure:Naiym224@cluster1.0j9choj.mongodb.net/MiddleManBot",
}
